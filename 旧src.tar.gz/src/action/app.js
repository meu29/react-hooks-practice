/* アクション(stateをどのように更新するかのメッセージ？)をリデューサーに送信 */
/*export default {
    increment: () => {
        return {type: "INCREMENT"};
    },
    decrement: () => {
        return {type: "DECREMENT"};
    }
}*/

var increment = () => { return {type: "INCREMENT"}; }

export default increment;