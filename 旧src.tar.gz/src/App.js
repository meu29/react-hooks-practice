import React from "react"
import { connect } from "react-redux"
import increment from "./action/app"

var AppComponent = () => {

  return(
    <div>
      {/* reducer.jsのinitState */}
      <p>{this.props.count}</p>
      <input type="button" onClick={() => this.props.handleClick} />
    </div>
  )

}

//export default AppComponent;
/* stateをpropsとして扱うための関数 */
var mapStateToProps = (state) => {
  return {
    count: state
  }
}

var mapDispatchToProps = (dispatch) => {
  return {
      /* ボタンが押される -> ディスパッチ(アクションを決める？) */
      handleClick: () => { dispatch(increment()); }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AppComponent);