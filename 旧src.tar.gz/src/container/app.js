import { connect } from "react-redux"
import AppComponent from "../App"
import { increment, decrement } from "../action/app"

/* stateをpropsとして扱うための関数 */
var mapStateToProps = (state) => {
    return state;
}

var mapDispatchToProps = (dispatch) => {
    return {
        /* ボタンが押される -> ディスパッチ(アクションを決める？) */
        handleClick: () => { dispatch(increment()); }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(AppComponent);